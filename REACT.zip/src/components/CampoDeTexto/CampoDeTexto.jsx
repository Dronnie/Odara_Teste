/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const CampoDeTexto = ({ className, divClassName, text = "Texto" }) => {
  return (
    <div
      className={`flex w-[285px] items-center justify-between px-[11px] py-3 relative rounded-[20px] overflow-hidden border border-solid border-[#9a9a9a] shadow-[0px_4px_4px_#00000040] ${className}`}
    >
      <div
        className={`relative w-[42px] h-[19px] mt-[-0.50px] [font-family:'Inter',Helvetica] font-normal text-[#9a9a9a] text-base tracking-[0] leading-[normal] whitespace-nowrap ${divClassName}`}
      >
        {text}
      </div>
      <img className="relative w-5 h-5" alt="Visibility off" src="/img/visibility-off.png" />
    </div>
  );
};

CampoDeTexto.propTypes = {
  text: PropTypes.string,
};
