import { CampoDeTexto } from ".";

export default {
  title: "Components/CampoDeTexto",
  component: CampoDeTexto,
};

export const Default = {
  args: {
    className: {},
    divClassName: {},
    text: "Texto",
  },
};
