export { CampoDeTexto } from "./CampoDeTexto";
