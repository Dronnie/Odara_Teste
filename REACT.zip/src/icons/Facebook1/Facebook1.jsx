/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Facebook1 = ({ className }) => {
  return (
    <svg
      className={`${className}`}
      fill="none"
      height="50"
      viewBox="0 0 51 50"
      width="51"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M42.6875 0H8.3125C3.99778 0 0.5 3.49778 0.5 7.8125V42.1875C0.5 46.5022 3.99778 50 8.3125 50H42.6875C47.0022 50 50.5 46.5022 50.5 42.1875V7.8125C50.5 3.49778 47.0022 0 42.6875 0Z"
        fill="#1877F2"
      />
      <path
        d="M38 25C38 18.125 32.375 12.5 25.5 12.5C18.625 12.5 13 18.125 13 25C13 31.25 17.5312 36.4062 23.4687 37.3437V28.5937H20.3437V25H23.4687V22.1875C23.4687 19.0625 25.3438 17.3438 28.1563 17.3438C29.5625 17.3438 30.9688 17.6563 30.9688 17.6563V20.7813H29.4062C27.8438 20.7813 27.375 21.7187 27.375 22.6562V25H30.8125L30.1875 28.5937H27.2188V37.5C33.4688 36.5625 38 31.25 38 25Z"
        fill="white"
      />
    </svg>
  );
};
