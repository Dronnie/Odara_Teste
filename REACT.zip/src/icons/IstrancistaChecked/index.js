export { IstrancistaChecked } from "./IstrancistaChecked";
