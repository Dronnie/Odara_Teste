export { TikTok1 } from "./TikTok1";
