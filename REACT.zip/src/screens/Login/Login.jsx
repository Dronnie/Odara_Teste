import React from "react";
import { CampoDeTexto } from "../../components/CampoDeTexto";
import { Facebook1 } from "../../icons/Facebook1";
import { Footer } from "../../icons/Footer";
import { Google1 } from "../../icons/Google1";
import { TikTok1 } from "../../icons/TikTok1";
import { Twitter1 } from "../../icons/Twitter1";

export const Login = () => {
  return (
    <div className="bg-white flex flex-row justify-center w-full">
      <div className="bg-white w-[390px] h-[844px] relative">
        <img className="absolute w-8 h-8 top-[73px] left-[348px]" alt="Whatsapp" src="/img/whatsapp.svg" />
        <div className="absolute w-[286px] h-[393px] top-[225px] left-[52px]">
          <div className="inline-flex items-center justify-center gap-2.5 px-[90px] py-2.5 absolute top-[349px] left-0 rounded-[20px] border border-solid border-padr-o-fonte">
            <div className="relative w-fit mt-[-1.00px] [font-family:'Inter',Helvetica] font-normal text-padr-o-fonte text-xl tracking-[0] leading-[normal] whitespace-nowrap">
              Criar conta
            </div>
          </div>
          <div className="inline-flex flex-col items-center justify-center gap-5 absolute top-0 left-px">
            <div className="flex w-[285px] items-center gap-11 px-[11px] py-3 relative flex-[0_0_auto] rounded-[20px] overflow-hidden border border-solid border-[#9a9a9a] shadow-[0px_4px_4px_#00000040]">
              <div className="self-stretch w-[42px] mt-[-1.00px] relative [font-family:'Inter',Helvetica] font-normal text-[#9a9a9a] text-base tracking-[0] leading-[normal] whitespace-nowrap">
                Email
              </div>
            </div>
            <CampoDeTexto className="!flex-[0_0_auto]" divClassName="!h-[unset] !w-fit" text="Senha" />
            <img className="relative w-[285px] flex-[0_0_auto]" alt="Boto" src="/img/bot-o.svg" />
            <div className="inline-flex flex-col items-center gap-6 relative flex-[0_0_auto]">
              <div className="relative w-fit mt-[-1.00px] [font-family:'Inter',Helvetica] font-normal text-[#615959] text-base tracking-[0] leading-[normal] whitespace-nowrap">
                Outras formas de login
              </div>
              <div className="inline-flex items-start gap-7 relative flex-[0_0_auto]">
                <Google1 className="!relative !w-[50px] !h-[50px]" />
                <Facebook1 className="!relative !w-[50px] !h-[50px]" />
                <TikTok1 className="!relative !w-[50px] !h-[50px]" />
                <Twitter1 className="!relative !w-[50px] !h-[50px]" />
              </div>
            </div>
          </div>
        </div>
        <img
          className="absolute w-[180px] h-[113px] top-[73px] left-[105px]"
          alt="Logo odara roxo e"
          src="/img/logo-odara-roxo-e-vermelho-1.png"
        />
        <Footer className="!absolute !w-[390px] !h-[47px] !top-[797px] !left-0" />
        <p className="absolute top-[663px] left-[72px] [font-family:'Inter',Helvetica] font-normal text-[#9a9a9a] text-sm tracking-[0] leading-[normal]">
          <span className="[font-family:'Inter',Helvetica] font-normal text-[#9a9a9a] text-sm tracking-[0]">
            Problemas para acessar?{" "}
          </span>
          <span className="underline">Clique aqui!</span>
        </p>
        <div className="absolute top-[646px] left-[378px] [font-family:'Inter',Helvetica] font-normal text-black text-sm tracking-[0] leading-[normal]">
          {""}
        </div>
        <div className="flex w-[390px] h-12 items-end justify-between px-6 py-2.5 fixed top-0 left-0 bg-white">
          <div className="relative w-fit [font-family:'Roboto',Helvetica] font-medium text-m-3refneutralneutral-10 text-sm tracking-[0.14px] leading-5 whitespace-nowrap">
            9:30
          </div>
          <div className="relative w-[46px] h-[17px]">
            <div className="absolute w-[33px] h-[17px] top-0 left-0">
              <div className="absolute w-[17px] h-[17px] top-0 left-0 bg-[url(/static/img/path-4.png)] bg-[100%_100%]">
                <div className="relative h-[17px] bg-[url(/static/img/path-4.png)] bg-[100%_100%]">
                  <img className="absolute w-[17px] h-3.5 top-px left-0" alt="Path" src="/img/path-5.svg" />
                </div>
              </div>
              <img className="absolute w-[17px] h-[17px] top-0 left-4" alt="Signal" src="/img/signal-1.png" />
            </div>
            <img className="absolute w-2 h-[15px] top-px left-[38px]" alt="Battery" src="/img/battery-1.svg" />
          </div>
        </div>
      </div>
    </div>
  );
};
